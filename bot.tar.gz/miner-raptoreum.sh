#!/bin/sh
#
while [ 1 ]; do
./cpuminer-sse2 -a gr -o stratum+tcps://stratum-eu.rplant.xyz:17056 -u RCkP5oaa2mS9v3dNfUG9B9Drh73vMS8b5o.dodot
sleep 5
done
